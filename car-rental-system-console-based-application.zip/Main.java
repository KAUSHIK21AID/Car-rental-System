import java.util.*;
class User
{
    String username;
    String password;
    public String getname()
    {
        return username;
    }
    public String getpwd()
    {
        return password;
    }
    public User(String username, String password)
    {
        this.username = username;
        this.password = password;
    }
}
class Cars
{
    int carid, capacity, rentph;
    String carbrand;
    public String getcarbrand()
    {
        return carbrand;
    }
    public int getcapacity()
    {
        return capacity;
    }
    public int getcarid()
    {
        return carid;
    }
    public int getrent()
    {
        return rentph;
    }
    public Cars(int carid, String carbrand, int capacity, int rentph)
    {
        this.carid = carid;
        this.carbrand = carbrand;
        this.capacity = capacity;
        this.rentph = rentph;
    }
    
}
class Booking
{
    String username;
    int carid;
    String starttime;
    int duration;
    public int getduration()
    {
        return duration;
    }
    public Booking(String username, int carid, String starttime, int duration)
    {
        this.username = username;
        this.carid = carid;
        this.starttime = starttime;
        this.duration  = duration;
    }
}
class Main
{
    public static void remaining_cars(List<Cars>c)
    {
        System.out.println("The number of cars remaining is: "+c.size());
    }
    public static void displaycars(List<Cars>c)
    {
        System.out.println("Availabe caars in the rental system are:");
        for(Cars k:c)
        {
            System.out.println("Brand Name"+k.getcarbrand()+"-->  Capacity: "+k.getcapacity()+"-->  Rent per hour: "+k.getrent());
        }
    }
    public static List<Booking> cancel(List<Booking>b, Booking b1)
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Option 2(Cancel),5(Bye): ");
        int opt =sc.nextInt();
        if(opt==5)
        {
            System.out.print("BYE! happy ride !!!!!");
        }
        // else if(opt==3)
        // {
        //     return update(b,b1);
        // }
        else if(opt==2)
        {
            return delete(b,b1);
        }
        return b;
    }
    // public List<Booking> update(List<Booking>b,Booking b1)
    // {
    //     for(Booking bb:b)
    //     {
    //         if(bb.getcarbrand().equals(b1.getcarbrand()))
    //         {
    //             System.out.println("Enter new duration:");
    //             int nd = sc.nextInt();
    //             b1.duration = nd;
    //             b.remove(b1);
    //             b.add(b1);
    //             return b;
    //         }
    //     }
    //     return b;
    // }
    public static List<Booking> delete(List<Booking>b, Booking b1)
    {
        b.remove(b1);
        return b;
    }
    public static void main(String[]args)
    {
        Scanner sc = new Scanner(System.in);
        List<User>users = new ArrayList<>();
        List<Cars>carsss = new ArrayList<>();
        List<Booking>bookings = new ArrayList<>();
        
        //SIGNUP
        for(int i=0;i<2;i++)
        {
            System.out.println("Signup:");
            String entername = sc.next();
            String enterpwd =sc.next();
            if(!users.contains(entername))
            {
                User u = new User(entername,enterpwd);
                users.add(u);
            }
            else
            {
                System.out.println("User already exixts in the Database");
            }
        }
        // User u1 = new User("Snake_babu","Vadivelu");
        // users.add(u1);
        // User u2 = new User("Sangi_Mangi","pokkiri");
        // users.add(u2);
        
        Cars c1 = new Cars(1,"Innova",7,400);
        carsss.add(c1);
        Cars c2 = new Cars(2, "Polo",5,250);
        carsss.add(c2);
        Cars c3 = new Cars(3,"Nano",4,200);
        carsss.add(c3);
        
        
        
        System.out.println("Enter Username: ");
        String log_user = sc.next();
        System.out.println("Enter Password: ");
        String log_pwd = sc.next();
        
        // int option = sc.nextInt();
        int flag=0,exist=0;
        for(User i:users)
        {
            if(i.getname().equals(log_user))
            {
                exist=1;
                if(!i.getpwd().equals(log_pwd))
                {
                    flag = 1;
                    System.out.println("Invalid Password, Please try logging in again");
                    break;
                }
                else
                {
                    displaycars(carsss);
                    System.out.println("Enter required car: ");
                    String req_car = sc.next();
                    for(Cars j:carsss)
                    {
                        if(j.getcarbrand().equals(req_car))
                        {
                            System.out.println("Enter Start time: ");
                            String starttime = sc.next();
                            System.out.println("Enter Required duration: ");
                            int duration = sc.nextInt();
                            Booking b1 = new Booking(log_user,j.getcarid(),starttime, duration);
                            bookings.add(b1);
                            // Cars jj = j;
                            carsss.remove(j);
                            System.out.println("Car booked! Happy ride!!!");
                            bookings = cancel(bookings,b1);
                            if(bookings.size()==0)
                            {
                                carsss.add(j);
                            }
                        }
                    }
                }
            }
        }
        if(exist==0)
        {
            System.out.println("user does not exists in the database");
        }
        remaining_cars(carsss);
        
        System.out.print("Admin, do u ant to add cars: ");
        int o = sc.nextInt();
        if(o==1)
        {
            System.out.print("How many?");
            int nn = sc.nextInt();
            for(int i=0;i<nn;i++)
            {
                int ncarid =sc.nextInt();
                String newcar = sc.next();
                int ncapa = sc.nextInt();
                int newrph =sc.nextInt();
                Cars c4 = new Cars(ncarid,newcar,ncapa,newrph);
                carsss.add(c4);
            }
            
            remaining_cars(carsss);
        }
        System.out.print("Admin, do u ant to del cars: ");
        int d = sc.nextInt();
        if(d==1)
        {
            
            System.out.print("How many?");
            int nn = sc.nextInt();
            for(int i=0;i<nn;i++)
            {
                int ncarid =sc.nextInt();
                for(Cars c: carsss)
                {
                    if(c.getcarid()==ncarid)
                    {
                        carsss.remove(c);
                    }
                }
            }
            remaining_cars(carsss);
        }
    }
    
}